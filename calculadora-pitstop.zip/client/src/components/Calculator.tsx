import { useState, useEffect } from "react";
import CalculatorSection from "./CalculatorSection";
import { 
  mechanicalParts, 
  bodyParts, 
  interiorItems, 
  wheelItems, 
  lightItems, 
  extraItems, 
  paintItems, 
  repairItems 
} from "@/data/vehiclePrices";
import { formatCurrency } from "@/lib/utils";

interface ItemState {
  quantity: number;
  price: number;
}

interface SectionState {
  [key: string]: ItemState;
}

interface Item {
  id: string;
  name: string;
  price: number;
  usePercentage?: boolean;
}

interface CalculatorState {
  vehicleValue: number;
  mecanica: SectionState;
  carroceria: SectionState;
  interior: SectionState;
  ruedas: SectionState;
  luces: SectionState;
  extras: SectionState;
  pintura: SectionState;
  reparacion: SectionState;
}

export default function Calculator() {
  const [showAllBodyParts, setShowAllBodyParts] = useState(false);
  const [grandTotal, setGrandTotal] = useState(0);
  const [state, setState] = useState<CalculatorState>({
    vehicleValue: 0,
    mecanica: {},
    carroceria: {},
    interior: {},
    ruedas: {},
    luces: {},
    extras: {},
    pintura: {},
    reparacion: {},
  });

  // Initialize state with all items set to zero
  useEffect(() => {
    const initialState: CalculatorState = {
      vehicleValue: 0,
      mecanica: {},
      carroceria: {},
      interior: {},
      ruedas: {},
      luces: {},
      extras: {},
      pintura: {},
      reparacion: {},
    };
    
    // Set initial state for all items
    mechanicalParts.forEach(item => {
      initialState.mecanica[item.id] = { quantity: 0, price: 0 };
    });
    
    bodyParts.forEach(item => {
      initialState.carroceria[item.id] = { quantity: 0, price: 0 };
    });
    
    interiorItems.forEach(item => {
      initialState.interior[item.id] = { quantity: 0, price: 0 };
    });
    
    wheelItems.forEach(item => {
      initialState.ruedas[item.id] = { quantity: 0, price: 0 };
    });
    
    lightItems.forEach(item => {
      initialState.luces[item.id] = { quantity: 0, price: 0 };
    });
    
    extraItems.forEach(item => {
      initialState.extras[item.id] = { quantity: 0, price: 0 };
    });
    
    paintItems.forEach(item => {
      initialState.pintura[item.id] = { quantity: 0, price: 0 };
    });
    
    repairItems.forEach(item => {
      initialState.reparacion[item.id] = { quantity: 0, price: 0 };
    });
    
    setState(initialState);
  }, []);

  // Update grand total when state changes
  useEffect(() => {
    calculateGrandTotal();
  }, [state]);

  const handleVehicleValueChange = (value: number) => {
    setState(prev => ({
      ...prev,
      vehicleValue: value
    }));
    updateAllPrices(value);
  };

  const handleQuantityChange = (
    section: keyof Omit<CalculatorState, 'vehicleValue'>, 
    itemId: string, 
    quantity: number, 
    basePrice: number,
    usePercentage: boolean = false
  ) => {
    let price = 0;
    
    if (usePercentage) {
      // Calculate price based on vehicle value percentage
      const percentage = basePrice / 100; // Convert to decimal
      price = state.vehicleValue * percentage * quantity;
    } else {
      // Fixed price calculation
      price = basePrice * quantity;
    }
    
    setState(prev => {
      const newState = { ...prev };
      const sectionState = { ...newState[section] };
      sectionState[itemId] = { quantity, price };
      newState[section] = sectionState;
      return newState;
    });
  };

  const updateAllPrices = (vehicleValue: number) => {
    // Create a deep copy of the state to avoid mutation
    const newState = { ...state };
    newState.vehicleValue = vehicleValue;
    
    // List of sections to process
    const sections: Array<keyof Omit<CalculatorState, 'vehicleValue'>> = [
      'mecanica', 'carroceria', 'interior', 'ruedas', 'luces', 'extras', 'pintura', 'reparacion'
    ];
    
    // Recalculate prices for all items that use vehicle value percentage
    sections.forEach(section => {
      const sectionState = { ...newState[section] };
      
      Object.keys(sectionState).forEach(itemId => {
        const item = sectionState[itemId];
        const quantity = item.quantity;
        
        // Find the item in the data to get the base price and whether it uses percentage
        const itemData = findItemById(itemId) as Item | undefined;
        
        if (itemData && itemData.usePercentage) {
          const percentage = itemData.price / 100; // Convert to decimal
          sectionState[itemId] = {
            ...item,
            price: vehicleValue * percentage * quantity
          };
        }
      });
      
      newState[section] = sectionState;
    });
    
    setState(newState);
  };

  const findItemById = (id: string) => {
    const allItems = [
      ...mechanicalParts, 
      ...bodyParts, 
      ...interiorItems, 
      ...wheelItems, 
      ...lightItems, 
      ...extraItems, 
      ...paintItems, 
      ...repairItems
    ];
    
    return allItems.find(item => item.id === id);
  };

  const calculateGrandTotal = () => {
    let total = 0;
    
    // Sum all section totals
    Object.keys(state).forEach(sectionKey => {
      if (sectionKey === 'vehicleValue') return;
      
      const section = state[sectionKey as keyof Omit<CalculatorState, 'vehicleValue'>];
      
      Object.values(section).forEach(item => {
        total += item.price;
      });
    });
    
    setGrandTotal(total);
  };

  const resetCalculator = () => {
    // Reset all inputs to 0
    const resetState = { ...state, vehicleValue: 0 };
    
    Object.keys(resetState).forEach(sectionKey => {
      if (sectionKey === 'vehicleValue') return;
      
      const section = sectionKey as keyof Omit<CalculatorState, 'vehicleValue'>;
      
      Object.keys(resetState[section]).forEach(itemId => {
        resetState[section][itemId] = { quantity: 0, price: 0 };
      });
    });
    
    setState(resetState);
    setGrandTotal(0);
  };

  const toggleBodyworkItems = () => {
    setShowAllBodyParts(!showAllBodyParts);
  };

  return (
    <>
      {/* Vehicle Value Section */}
      <div className="bg-[rgba(36,41,46,0.6)] backdrop-blur-xl rounded-[20px] shadow-lg p-5 mb-6 transition-all duration-300 hover:shadow-xl hover:shadow-[#1f6feb]/10 animate-[fadeIn_0.6s_ease-in]" style={{ animationDelay: '0.1s' }}>
        <h2 className="text-xl font-semibold text-[#58a6ff] mb-4 flex items-center">
          <span className="mr-2">🚗</span> Valor del Vehículo
        </h2>
        <div className="relative">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">$</span>
          <input 
            type="number" 
            id="valorVehiculo" 
            className="bg-[#0d1117]/70 w-full rounded-lg border border-gray-700 px-8 py-3 transition-all focus:border-[#58a6ff] focus:ring-2 focus:ring-[#58a6ff]/30 focus:outline-none text-[#f0f6fc]"
            value={state.vehicleValue || ''}
            onChange={(e) => handleVehicleValueChange(parseFloat(e.target.value) || 0)}
            min="0" 
            step="any"
          />
        </div>
      </div>

      {/* Divider */}
      <div className="h-px w-11/12 mx-auto bg-gradient-to-r from-transparent via-[#58a6ff66] to-transparent my-8"></div>

      {/* Mechanical Section */}
      <CalculatorSection 
        title="Mecánica" 
        icon="🛠️" 
        items={mechanicalParts}
        section="mecanica"
        state={state.mecanica}
        onQuantityChange={(itemId, quantity, basePrice, usePercentage) => 
          handleQuantityChange('mecanica', itemId, quantity, basePrice, usePercentage)}
        animationDelay="0.2s"
      />

      {/* Bodywork Section */}
      <CalculatorSection 
        title="Carrocería" 
        icon="🚗" 
        items={showAllBodyParts ? bodyParts : bodyParts.slice(0, 3)}
        section="carroceria"
        state={state.carroceria}
        onQuantityChange={(itemId, quantity, basePrice, usePercentage) => 
          handleQuantityChange('carroceria', itemId, quantity, basePrice, usePercentage)}
        animationDelay="0.3s"
        showToggle={bodyParts.length > 3}
        toggleLabel={showAllBodyParts ? "Mostrar menos elementos de carrocería" : "Mostrar más elementos de carrocería"}
        onToggle={toggleBodyworkItems}
      />

      {/* Interior Section */}
      <CalculatorSection 
        title="Cosméticos Interiores" 
        icon="✨" 
        items={interiorItems}
        section="interior"
        state={state.interior}
        onQuantityChange={(itemId, quantity, basePrice, usePercentage) => 
          handleQuantityChange('interior', itemId, quantity, basePrice, usePercentage)}
        animationDelay="0.4s"
      />

      {/* Grid of 2 sections - Wheels and Lights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Wheels Section */}
        <CalculatorSection 
          title="Ruedas" 
          icon="🛞" 
          items={wheelItems}
          section="ruedas"
          state={state.ruedas}
          onQuantityChange={(itemId, quantity, basePrice, usePercentage) => 
            handleQuantityChange('ruedas', itemId, quantity, basePrice, usePercentage)}
          animationDelay="0.5s"
          compact={true}
        />

        {/* Lights Section */}
        <CalculatorSection 
          title="Luces" 
          icon="💡" 
          items={lightItems}
          section="luces"
          state={state.luces}
          onQuantityChange={(itemId, quantity, basePrice, usePercentage) => 
            handleQuantityChange('luces', itemId, quantity, basePrice, usePercentage)}
          animationDelay="0.5s"
          compact={true}
        />
      </div>

      {/* Extras Section */}
      <CalculatorSection 
        title="Extras" 
        icon="➕" 
        items={extraItems}
        section="extras"
        state={state.extras}
        onQuantityChange={(itemId, quantity, basePrice, usePercentage) => 
          handleQuantityChange('extras', itemId, quantity, basePrice, usePercentage)}
        animationDelay="0.6s"
      />

      {/* Paint Section */}
      <CalculatorSection 
        title="Pintura" 
        icon="🎨" 
        items={paintItems}
        section="pintura"
        state={state.pintura}
        onQuantityChange={(itemId, quantity, basePrice, usePercentage) => 
          handleQuantityChange('pintura', itemId, quantity, basePrice, usePercentage)}
        animationDelay="0.7s"
      />

      {/* Repair Section */}
      <CalculatorSection 
        title="Reparaciones" 
        icon="🔧" 
        items={repairItems}
        section="reparacion"
        state={state.reparacion}
        onQuantityChange={(itemId, quantity, basePrice, usePercentage) => 
          handleQuantityChange('reparacion', itemId, quantity, basePrice, usePercentage)}
        animationDelay="0.8s"
      />

      {/* Total Section */}
      <div className="bg-[rgba(36,41,46,0.6)] backdrop-blur-xl rounded-[20px] shadow-lg p-6 mb-6 transition-all duration-300 hover:shadow-xl hover:shadow-[#1f6feb]/10 animate-[fadeIn_0.6s_ease-in]" style={{ animationDelay: '0.9s' }}>
        <h2 className="text-xl font-semibold text-[#58a6ff] mb-4 flex items-center justify-center">
          <span className="mr-2">💰</span> Precio Total
        </h2>
        
        <div className="text-3xl font-bold text-center py-4 bg-[#0d1117]/50 rounded-lg mb-6 text-[#79c0ff] animate-pulse">
          {formatCurrency(grandTotal)}
        </div>
        
        <div className="flex justify-center">
          <button 
            onClick={resetCalculator}
            className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white py-3 px-8 rounded-lg font-bold transition-all duration-300 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-red-500/50"
          >
            Resetear
          </button>
        </div>
      </div>
    </>
  );
}
