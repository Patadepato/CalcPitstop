// Configuration for vehicle modification pricing

// Mechanical parts - All use 2.062% of vehicle value
export const mechanicalParts = [
  { id: "motor", name: "Motor", price: 2.062, usePercentage: true },
  { id: "frenos", name: "Frenos", price: 2.062, usePercentage: true },
  { id: "transmision", name: "Transmisión", price: 2.062, usePercentage: true },
  { id: "suspension", name: "Suspensión", price: 2.062, usePercentage: true },
  { id: "turbo", name: "Turbo", price: 2.062, usePercentage: true }
];

// Body parts (carrocería) - All use 2% of vehicle value
export const bodyParts = [
  { id: "aleron", name: "Alerón", price: 2, usePercentage: true },
  { id: "parachoqD", name: "Parachoques delantero", price: 2, usePercentage: true },
  { id: "parachoqT", name: "Parachoques trasero", price: 2, usePercentage: true },
  { id: "tuboEscape", name: "Tubo de escape", price: 2, usePercentage: true },
  { id: "jaula", name: "Jaula", price: 2, usePercentage: true },
  { id: "parrilla", name: "Parrilla", price: 2, usePercentage: true },
  { id: "capo", name: "Capó", price: 2, usePercentage: true },
  { id: "guardabarrosIzq", name: "Guardabarros izquierdo", price: 2, usePercentage: true },
  { id: "guardabarrosDer", name: "Guardabarros derecho", price: 2, usePercentage: true },
  { id: "techo", name: "Techo", price: 2, usePercentage: true },
  { id: "guardabarros", name: "Guardabarros", price: 2, usePercentage: true },
  { id: "antena", name: "Antena", price: 2, usePercentage: true },
  { id: "alas", name: "Alas", price: 2, usePercentage: true },
  { id: "faldones", name: "Faldones laterales", price: 2, usePercentage: true },
  { id: "ventana", name: "Ventana", price: 2, usePercentage: true },
  { id: "altavoces", name: "Altavoces", price: 2, usePercentage: true },
  { id: "maletero", name: "Maletero", price: 2, usePercentage: true },
  { id: "bloqueMotor", name: "Bloque de motor", price: 2, usePercentage: true },
  { id: "filtroAire", name: "Filtro de aire", price: 2, usePercentage: true },
  { id: "puntales", name: "Puntales", price: 2, usePercentage: true },
  { id: "cosmeticos", name: "Cosméticos", price: 2, usePercentage: true }
];

// Interior cosmetics - Fixed prices
export const interiorItems = [
  { id: "neones", name: "Instalación Neones", price: 2500 },
  { id: "mandoNeones", name: "Mando para Neones", price: 5000 },
  { id: "nitro", name: "Nitro + Instalación", price: 1000 },
  { id: "rellenoNitro", name: "Relleno Nitro", price: 7500 },
  { id: "colorNitro", name: "Color Nitro", price: 2000 }
];

// Wheels - Fixed price
export const wheelItems = [
  { id: "llantas", name: "Llantas y Neumático", price: 250 }
];

// Lights - Fixed price for both
export const lightItems = [
  { id: "xenon", name: "Xenon", price: 500 },
  { id: "colorXenon", name: "Color Xenon", price: 500 }
];

// Extras - Mixed pricing
export const extraItems = [
  { id: "extras", name: "Extras", price: 2, usePercentage: true },
  { id: "claxon", name: "Claxon", price: 250 },
  { id: "tintado", name: "Tintar Ventanas", price: 250 }
];

// Paint - All fixed at 500
export const paintItems = [
  { id: "principal", name: "Principal", price: 500 },
  { id: "secundario", name: "Secundario", price: 500 },
  { id: "perlado", name: "Perlado", price: 500 },
  { id: "vinilos", name: "Vinilos", price: 500 }
];

// Repairs - Fixed prices
export const repairItems = [
  { id: "leve", name: "Reparación Leve", price: 500 },
  { id: "media", name: "Reparación Media", price: 750 },
  { id: "grave", name: "Reparación Grave", price: 1000 }
];
