import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // For this calculator app, we don't need any API routes
  // as all calculations are done client-side
  
  // Serve a health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', version: '1.0.0' });
  });

  const httpServer = createServer(app);

  return httpServer;
}
